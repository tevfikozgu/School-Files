/* @Hatice K�se
* Student Name: <Tolga �nkaya>
* Student ID : <150140715>
* Date: <24 December 2018> */
#include <iostream>
#define SIZE 100000
using namespace std;
// struction for linked list to use in pathSum function which is member of Tree  
struct node{
	int data;
	node *next;
};

// Struction to construct Tree
struct Node{
	int data;
	Node* leftChild;
	Node* rightChild;
};
/* ------------------------ FUNCTIONS FOR LINKED LIST -------------------------------- */

// push function inserts element to the end of the linked list.
void push(node** head, int val){
	node* inserted = new node;
	inserted->data = val;
	inserted->next = NULL;
	if(*head == NULL)
	{
		*head = inserted;
		return;
	}
	node *temp = *head;
	while(temp->next!=NULL){
		temp = temp->next;
	}
	temp->next = inserted;
}

// PrintList is used for print out all of the elements of the linked lists.
void PrintList(node* head)
{
	if(head == NULL) return;
	
	node* temp = head;
	while(temp)
	{
		cout << temp->data << " ";
		temp = temp->next;
	}
}

// This function actually same as pop function, it deletes element from end of the linked list.
void deleteLast(node** head){
	if(*head == NULL) return;
	node *prev = new node;
	node *deleted = *head;
	while(deleted->next!=NULL){
		prev = deleted;
		deleted = deleted->next;
	}
	prev->next = NULL;
	delete(deleted);
}
/* -------------------------- END OF LINKED LIST FUNCTIONS ------------------------- */

// Struction for our actual Tree
struct Tree {
	Node *root;
	Node *Insert(int*, Node*, int, int);  
	void printPreorder(Node*);
	void deleteTree(Node**);
	void readFile(char*, int[], int*);
};

void deleteTree(Node**);
void deleteNodes(Node*);

/*  --------------------------- TREE MEMBER FUNCTIONS and OTHER FUNCTIONS  --------------------------- */

/*------------------------------ PART II. Path of a Sum in a Binary Tree -------------------------------*/
void pathSum(Node* root, node** head, int sum, int sum_till_now, Node* foo, int *checker){
	if(root == NULL) return;
	
	sum_till_now += root->data;
	push(head, root->data);
	if(sum_till_now == sum){
		cout<<"Path Found: ";
		PrintList(*head);
		cout << endl;
		deleteTree(&foo);
		*checker = 1;
	}
	/*---------------------------------- RECCURSIVE PREORDER TRAVERSAL ---------------------------*/
	if (root->leftChild != NULL)
	{
        pathSum(root->leftChild, head, sum, sum_till_now, foo, checker);
    }
    if (root->rightChild != NULL) 
    {
        pathSum(root->rightChild, head, sum, sum_till_now, foo, checker); 
    }
    
    deleteLast(head);
}

// This is base function for deleteTree which deletes all possible nodes instead of the root. We should delete  the root by using another function. 
void deleteNodes(Node *foo){
	
	if (foo == NULL) return;
	deleteNodes(foo->leftChild);
	deleteNodes(foo->rightChild);
	delete(foo);
}

/* This Function delete all Trees. This function should be used to delete all dynamically created memory in heap. This is our responsible, otherwise
   this may be cause memory crush or fault in next future operation. This is secure way to avoid any possible error   */
void deleteTree(Node **foo){
	deleteNodes(*foo);
	foo = NULL;
}

// This function print all elements of the trees using preorder traversal
void Tree::printPreorder(Node* foo) {
	if (foo == NULL) return;
	cout << foo->data << " ";
	printPreorder(foo->leftChild);
	printPreorder(foo->rightChild);
}

// Create newnode for tree structure. This is base function for Insert function of Tree
Node* getNewNode(int data) {
	Node* newNode = new Node;
	newNode->data = data;
	newNode->leftChild = NULL;
	newNode->rightChild = NULL;
	return newNode;
}

/* ---------------------- PART I. Construct a Binary Tree --------------------------------- */
// This function realizes insertion in the tree level by level as mentioned hw instruction
Node* Tree::Insert(int arr[], Node *root, int l, int r)
{
	if (l < r)
	{
		Node* temp = getNewNode(arr[l]);
		root = temp;

		root->leftChild = Insert(arr,
			root->leftChild, 2 * l + 1, r);

		root->rightChild = Insert(arr,
			root->rightChild, 2 * l + 2, r);
	}
	return root;
}
/* --------------------- END OF PART I ---------------------------------*/

//
void Tree::readFile(char * text, int arr[SIZE], int *index)
{
	int n = 0;
	
	FILE* file = fopen(text, "r");  // command line
	// Check if text file does not exist
	if (file == NULL)
	{
		cout << "There is no text file!" << endl;
		return;
	}
	while (!feof(file)) 
	{
		fscanf(file, "%d ", &arr[n]);
		n++;
	}
	
	root = Insert(arr, root, 0, n-1);
	*index = n-1;
}

/*-------------------------END OF MEMBER FUNCTIONS -------------------------*/

/* ------------------------------- MAIN ---------------------------------- */
int main(int argc, char** argv) {
	if(argc!=2) return 0; // Error Handling 
	Tree Root;
	int arr[SIZE];
	int index;
	Root.readFile(argv[1], arr, &index); 
	node *head = NULL; // This is head for our singly linked list, it is used to store all elements which sums are equal to the given value.
	int sum = arr[index]-arr[0];
	push(&head, arr[0]);
	int checker = 0; // This is controller for if there exist given sum in LEFT subtree, after the obtaining the given sum, then it is conveted to 1.
	/* First, pathSum applies for LEFT subTree, if find any summation equal to given value then checker is converted to 1 else remains 0 */
	pathSum(Root.root->leftChild, &head, sum, 0, Root.root->leftChild, &checker);
	if(checker==0){
		cout<<"No Path Found"<<endl; // there is no summation equal to given value in the LEFT Subtree.
	}
	checker = 0; // This is controller for if there exist given sum in RIGHT subtree, after the obtaining the given sum, then it is conveted to 1.
	Root.readFile(argv[1], arr, &index);
	node *head2 = NULL;
	sum = arr[index]-arr[0];
	push(&head2, arr[0]);
	/* Second, pathSum applies for RIGHT subTree, if find any summation equal to given value then checker is converted to 1 else remains 0 */
	pathSum(Root.root->rightChild, &head2, sum, 0, Root.root->rightChild, &checker);
	if(checker==0){
		cout<<"No Path Found"<<endl; // there is no summation equal to given value in the RIGHT Subtree.
	}
	
	return 0;
}
