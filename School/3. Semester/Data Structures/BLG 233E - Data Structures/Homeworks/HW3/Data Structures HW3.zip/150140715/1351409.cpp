/* 
*   name: Tolga Inkaya
*   ID  : 150140715
*   <3th of December, 2018>   
*/
#include <iostream>
#include <ctype.h>
#include <cstdio>
#include <cstring>
#include <iomanip>
#include <cstdlib>
#include <fstream>
#include <string>
#include <sstream>
#include <math.h>
#define SIZE  1000
using namespace std;

// Struction for Linked List & Stack
struct Node{
	int data;
	Node* next;
};

// Stack Class

class Stack
{
	private:
	   Node* head;
	public:
	    // Constructor
		Stack()
		{
			head = NULL;
		}
    // Check whatever stack is empty or not
		bool isEmpty()
		{
			return head == NULL;
		}
        // Insert element to the top of the stack
		void push(int data)
		{
			Node* temp = new Node;
			temp->data = data;
			temp->next = head;
			head = temp;
		}
       // delete the top of the stack element
		int pop()
		{
			if(isEmpty())
			{
				return 0;
			}else
			{
           Node* temp = head;
		   head = head->next;
		   int d = temp->data;
		   delete(temp);
		   return d;
			}
		}
        // top element of the stack 
		int top()
		{
			return head->data;
		}
		// Show, print out all stack elements
		void Print()
		{
			if(isEmpty()) return;
			Node* temp = head;
			while(temp)
			{
				cout << temp->data << " ";
				temp = temp->next;
			}
		}
		// find the number of elements in the stack
		int length()
		{
			int count = 0;
			Node* temp = head;
			while(temp!=NULL)
			{
				count++;
				temp = temp->next;
			}
			return count;
		}

};




int main(int argc, char** argv) {
	int i,data, tableDeckCount, playerDeckCount;
	Stack tableDeck, player1Deck, player2Deck, binStack; // stack declarations
	int bin = 0;                
	//   int winCondition = 0;   WinCondition, if == 0 withdraw elseif == 1 player1 wins else player2 wins.
	FILE* file = fopen(argv[1], "r");  // command line
	// Check if text file does not exist
	if(file==NULL)
	{
		cout << "There is no text file!" << endl;
		return 0;
	}
	fscanf(file, "%d %d", &tableDeckCount, &playerDeckCount);
	// push cards into the table deck stack
	if(tableDeckCount == 0 || playerDeckCount == 0)
	{
		cout << bin << endl;
		return 0;
	}
	// checking for possible error
	if(tableDeckCount < 0 || playerDeckCount < 0)
	{
		cout << "Invalid input!" << endl;
		return 0;
	}
	for(i = 0; i<tableDeckCount; i++)
	{
		fscanf(file, "%d", &data);
		tableDeck.push(data);		
	}
	// push cards into the player1 deck stack
	for(i = 0; i<playerDeckCount; i++)
	{
		fscanf(file, "%d", &data);
		player1Deck.push(data);
	}
	// push cards into the player2 deck stack
	for(i = 0; i<playerDeckCount; i++)
	{
		fscanf(file, "%d", &data);
		player2Deck.push(data);
	}
	
	// Below code written to test all test files with manual input, it is not part of the main code. 
	/*
	cin >> tableDeckCount;
	cin >> playerDeckCount;
	for(i = 0; i<tableDeckCount; i++)
	{
		cin >> data;
		tableDeck.push(data);		
	}
	// push cards into the player1 deck stack
	for(i = 0; i<playerDeckCount; i++)
	{
		cin >> data;
		player1Deck.push(data);
	}
	// push cards into the player2 deck stack
	for(i = 0; i<playerDeckCount; i++)
	{
		cin >> data;
		player2Deck.push(data);
	}
	*/
	int turn = 1;   // round number,   if turn % 2 == 0 player2 turns else player1 turns. 
	int card, topCard;
	// Game loop
	while(!(tableDeck.isEmpty()))
	{
	
		card = tableDeck.top();
		int count = abs(card);   // how many operations will be realized in that round
		tableDeck.pop(); 
		// Player 1 Turns
		if(turn % 2 != 0)
		{
			if(card > 0)
			{
				while(!(player2Deck.isEmpty()) && count > 0)
				{
					
					topCard = player2Deck.top();
					if(topCard > player1Deck.top())
					{
					 player1Deck.push(topCard);
					}
					else
					{
						binStack.push(topCard);
						bin++;
					}
					player2Deck.pop();
					count--;
				}
			}else
			{
				while(!(player1Deck.isEmpty()) && count > 0)
				{
					topCard = player1Deck.top();
					if(topCard > player2Deck.top())
					{
					player2Deck.push(topCard);	
					}else
					{
						binStack.push(topCard);
						bin++;
					}
					player1Deck.pop();
					count--;

				}
			}
		}else
		{
			// Player2 turns
		    if(card > 0)
			{
				
				while(!(player1Deck.isEmpty()) && count > 0)
				{

					topCard = player1Deck.top();
					if(topCard > player2Deck.top())
					{
					player2Deck.push(topCard);	
					}else
					{
						binStack.push(topCard);
						bin++;
					}
					player1Deck.pop();
					count--;
				}
			}else
			{
				while(!(player2Deck.isEmpty()) && count > 0)
				{
					topCard = player2Deck.top();
					if(topCard > player1Deck.top())
					{
					player1Deck.push(topCard);
					}else
					{
						binStack.push(topCard);
						bin++;
					}
					player2Deck.pop();
					count--;
				}
			}
		}
		if(player1Deck.isEmpty())
		{
			cout << bin << endl;
			// winCondition = 1;
			break;
		}else if(player2Deck.isEmpty())
		{
			cout << bin << endl;
			// winCondition = 2;
			break;
		}else if(tableDeck.isEmpty())
		{
			if(player1Deck.length()<player2Deck.length())
			{
			    // winCondition = 1;   // Player 1 wins the game
			}else if(player2Deck.length()<player1Deck.length())
			{
				// winCondition = 2;   // Player 2 wins the game
			}else
			{
				//  winCondition = 0; // Withdraw
			}
			cout << bin << endl;
			break;
		}
		
		turn++;
	}
	
	
	
	
	return 0;
}

