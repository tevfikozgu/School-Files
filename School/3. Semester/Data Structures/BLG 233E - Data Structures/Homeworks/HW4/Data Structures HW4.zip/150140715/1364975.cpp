/* @Hatice K�se
* Student Name: <Tolga �nkaya>
* Student ID : <150140715>
* Date: <December 13, 2018> */

#include <iostream>
#include <cstdlib>
#include <fstream>
#define SIZE 100000

using namespace std;

// Struction for Singly Linked List
struct Node {
	int data;
	Node* next;
};

struct stackAnt{
	Node* head;

	void create();
	void close();
	void push(int);
	bool isEmpty();
	int top();
	void pop();
};

struct queueAnt{
	Node* front;
	Node* rear;

	void create();
	void close();
	void enQueue(int);
	void deQueue();
	bool isEmpty();
	int Front();
	void Print();
};

struct Ants {
	queueAnt ants;
	queueAnt holeDepths;
	stackAnt hole;
	void ReadFile(char *);
	void ShowContents(bool);
	void CrossRoad();
	void close();
};


//------------- MAIN --------------//
int main(int argc, char ** argv) {
	
	Ants a;
	a.ReadFile(argv[1]); // store the number of ants and depths of holes
	cout << "The initial Ant sequence is: ";
	a.ShowContents(1); // list ant sequence ( initially : 1, 2, ... , N)
	cout << "The depth of holes are: ";
	a.ShowContents(0); // list depth of holes
	a.CrossRoad();
	cout << "The final Ant sequence is: ";
	a.ShowContents(1);
	a.close();
	return 0;

}



//----- stackAnt Member Functions -----//

void stackAnt::create() {
	head = NULL;
}

void stackAnt::close() {
	Node* temp;
	while (head) {
		temp = head;
		head = head->next;
		delete temp;
	}
}

// Insert element to the top of the stack
void stackAnt::push(int data) {
	Node* temp = new Node;
	temp->data = data;
	temp->next = head;
	head = temp;
}

bool stackAnt::isEmpty()
{
	return head == NULL;
}

int stackAnt::top() {
	return head->data;
}

// delete the top of the stack element
void stackAnt::pop() {

	if (isEmpty()) return;
	Node* temp = head;
	head = head->next;

	delete(temp);
}

//----- End of the StackAnt Member Functions -----//


//-----  queueAnt Member Functions -----//

void queueAnt::create() {
	front = NULL;
	rear = NULL;
}

void queueAnt::close() {
	Node* temp;
	while (front) {
		temp = front;
		front = front->next;
		delete temp;
	}
}

void queueAnt::enQueue(int x) {
	Node* temp = new Node;
	temp->data = x;
	temp->next = NULL;
	if (isEmpty())
	{
		rear = temp;
		front = temp;
	}
	else {
		rear->next = temp;
		rear = temp;
	}
}

void queueAnt::deQueue() {
	if (isEmpty()) return;
	else if (front == rear)
	{
		front = NULL;
		rear = NULL;
		return;
	}
	Node* temp = front;
	front = front->next;
	delete(temp);
}

bool queueAnt::isEmpty() {
	return front == NULL;
}

int queueAnt::Front() {
	return front->data;
}

void queueAnt::Print() {
	if (isEmpty()) return;
	Node* temp = front;
	while (temp != NULL)
	{
		cout << temp->data << " ";
		temp = temp->next;
	}
	cout << endl;
}

//----- End of the queueAnt Member Functions -----//

// Read number of ants and the depths of holes dynamically
void Ants::ReadFile(char * text)
{
	int antCount;
	int arr[SIZE];
	FILE* file = fopen(text, "r");  // command line
	// Check if text file does not exist
	if (file == NULL)
	{
		cout << "There is no text file!" << endl;
		return;
	}

	fscanf(file, "%d ", &antCount);
	ants.create();
	for (int i = 1; i <= antCount; i++)
	{
		ants.enQueue(i);
	}
	int n = 0;
	holeDepths.create();
	while (!feof(file)) 
	{
		fscanf(file, "%d ", &arr[n]);
		n++;
	}
	for (int j = 0; j < n; j++)
	{
		holeDepths.enQueue(arr[j]);
	}
}
/* Prints out the contents of the queues according to bool argument. 
If true, prints out the contents of queueAnt ants; otherwise prints out the contents of queueAnt holeDepths. */
void Ants::ShowContents(bool a) {
	if (a == true)
	{
		ants.Print();
		return;
	}
	else {
		holeDepths.Print();
		return;
	}
 }

// This function makes all ants cross the road that contains several holes
void Ants::CrossRoad() {
	// create Hole
	hole.create();
	while (!holeDepths.isEmpty())
	{
		int depth = holeDepths.Front();
		holeDepths.deQueue();
		for (int i = 0; i < depth; i++)
		{
			int antToHole = ants.Front();
			ants.deQueue();
			hole.push(antToHole);
		}
		for (int j = 0; j < depth; j++)
		{
			int holeToAnt = hole.top();
			hole.pop();
			ants.enQueue(holeToAnt);
		}
	}
}

// Delete all dynamically allocated memory from the heap
void Ants::close() {
	ants.close();
	holeDepths.close();
	hole.close();
}